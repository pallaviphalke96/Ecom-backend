import React, { useState } from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axios from 'axios';

function CreateCouponComponent() {

    const [couponCode, setCouponCode] = useState('');
    const [discount, setDiscount] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          const response = await axios.post('http://localhost:8888/api/coupon', {
            couponCode: couponCode,
            discount: discount
          });
          console.log(response.status,'res--')
          if(response.status == 201){
            alert('Coupon created successfully')
          }else{
            alert('Error in creating coupon')
          }
          console.log(response.data,'data---'); // Assuming the API returns some response data
          // Add any further logic here, like showing success message, resetting form, etc.
        } catch (error) {
          console.error('Error creating coupon:', error);
          // Handle error - show error message to user, log error, etc.
        }
      };
    
  return (
    <div className='container'>
        <h3 style={{paddingTop:'150px'}}>Create Coupon</h3>
      <Form onSubmit={handleSubmit}>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Coupon Code</Form.Label>
        <Form.Control type="text" name='couponCode' placeholder="Enter Coupon Code"id="couponCode"
            value={couponCode}
            onChange={(e) => setCouponCode(e.target.value)}
 />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Discount</Form.Label>
        <Form.Control type="text" name='discount' placeholder="Enter Discount" id="discount"
            value={discount}
            onChange={(e) => setDiscount(e.target.value)}
/>
      </Form.Group>
      
      <Button variant="primary" type="submit">
        Create Coupon
      </Button>
    </Form>
    </div>
  )
}

export default CreateCouponComponent
