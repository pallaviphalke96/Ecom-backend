import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Table from 'react-bootstrap/Table';

const ShowAllCouponComponent = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:9091/api/coupon');
        setData(response.data);
        setLoading(false);
      } catch (error) {
        setError('An error occurred while fetching the data.');
        setLoading(false);
      }
    };

    fetchData();

    // Cleanup function
    return () => {
      // Cleanup code if needed
    };
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h2>All Coupon Details</h2>
      <Table striped bordered hover>
      <thead>
          <tr>
            <th>ID</th>
            <th>COUPON_CODE</th>
            <th>DISCOUNT</th>
          </tr>
        </thead>
        {console.log(data,'data---')}
        <tbody>
          {data.map((item) => (
            <tr key={item.couponId}>
              <td>{item.couponId}</td>
              <td>{item.couponCode}</td>
              <td>{item.discount}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default ShowAllCouponComponent;

