import React from 'react'
import axios from 'axios';
import { useState } from 'react';

function ShowAllOrders() {  


  const [orderId, setOrderId] = useState('');
  const [orderDetails, setOrderDetails] = useState([]);
  const [error, setError] = useState('');

  const handleFetchOrderDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:9091/api/order/${orderId}`);
      setOrderDetails(response.data); // Assuming the API returns details of the order
      setError('');
      console.log(response.data,'----data')
    } catch (error) {
      setError('Order not found or an error occurred while fetching order details.');
      console.error('Error fetching order details:', error);
      setOrderDetails(null);
    }
  };


    return (
        <div>
            <div>
      <h2>Order Details</h2>
      <div>
        <label htmlFor="orderId">Order ID:</label>
        <input
          type="text"
          id="orderId"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
        />
        <button onClick={handleFetchOrderDetails}>Fetch Details</button>
      </div>
      
      {orderDetails.order && (
        <div>
          <h3>Order ID: {orderDetails.order.id}</h3>
          <p>Item: {orderDetails.order.item}</p>
          <p>Price: {orderDetails.order.price}</p>
          <p>Status: {orderDetails.order.status}</p>
          {/* Add more details as needed */}
        </div>
      )}
      {orderDetails.coupon && (
        <div>
          <p>Coupon_Code: {orderDetails.coupon.couponCode}</p>
          <p>Discount: {orderDetails.coupon.discount}</p>
          {/* Add more details as needed */}
        </div>
      )}
      {error && <div>Error: {error}</div>}
    </div>
  </div>
    )
}

export default ShowAllOrders
