import React from 'react'
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import axios from 'axios';

function Order() {

    const [show, setShow] = useState(false);
    const [item, setItem] = useState('');
    const [couponId, setCouponID] = useState('');
    const [price, setPrice] = useState('');
    const [status,setStatus] = useState('');

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          const response = await axios.post('http://localhost:9091/api/order', {
            item: item,
            couponId: couponId,
            price:price,
            status:status
          });
          console.log(response.status,'res--')
          if(response.status == 201){
            alert('Order Place Successfully')
          }else{
            alert('Error in Order place')
          }
          console.log(response.data,'data---'); // Assuming the API returns some response data
          // Add any further logic here, like showing success message, resetting form, etc.
        } catch (error) {
          console.error('Error creating coupon:', error);
          // Handle error - show error message to user, log error, etc.
        }
      };

  return (
    <div>
       <h3 style={{textAlign:'center'}}>Order Details</h3>
      <div className='container' style={{textAlign:'center'}}>
      <Button variant="primary" onClick={handleShow} style={{alignItems:'center'}}>Place Order</Button>&nbsp;&nbsp;
      
      </div>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Place Order</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form>
        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Item</Form.Label>
        <Form.Control type="text" name='' placeholder="Enter Item name" id="item"
            value={item}
            onChange={(e) => setItem(e.target.value)}
        />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Price</Form.Label>
        <Form.Control type="text" name='' placeholder="Enter Item name" id="item"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
        />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Status</Form.Label>
        <Form.Control type="text" name='' placeholder="Enter Status" id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
        />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Coupon Code</Form.Label>
        <Form.Control type="text" name='' placeholder="Enter Coupon Code"id="couponCode"
            value={couponId}
            onChange={(e) => setCouponID(e.target.value)}
        />
      </Form.Group>
      </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSubmit}>
            Order
          </Button>
          
        </Modal.Footer>
      </Modal>

      
    </div>
  )
}

export default Order
