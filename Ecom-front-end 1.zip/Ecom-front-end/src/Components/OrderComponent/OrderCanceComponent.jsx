import React from 'react'
import { useState } from 'react';
import axios from 'axios';

function OrderCanceComponent() {
    const [orderId, setOrderId] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
  
    const handleCancelOrder = async () => {
      try {
        const response = await axios.put(`http://localhost:9091/api/order/cancel/${orderId}`);
        setMessage(response.data); // Assuming the API returns a success message
        setOrderId(''); // Clear orderId after successful cancellation
      } catch (error) {
        setError('An error occurred while cancelling the order.');
        console.error('Error cancelling order:', error);
      }
    };
  
    return (
        <div>
        <h2>Cancel Order</h2>
        {message && <div>{message}</div>}
        {error && <div>Error: {error}</div>}
        <label htmlFor="orderId">Order ID:</label>
        <input
          type="text"
          id="orderId"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
        />
        <button onClick={handleCancelOrder}>Cancel Order</button>
      </div>
  
    )
}

export default OrderCanceComponent
