import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import CreateCouponComponent from './Components/CouponComponent/CreateCouponComponent';
import NavigationComponent from './Components/NavigationComponent';
import {
  BrowserRouter,
  Routes,
  Route,
  NavLink
} from "react-router-dom";
import Order from './Components/OrderComponent/Order';
import OrderCanceComponent from './Components/OrderComponent/OrderCanceComponent'
import ShowAllCouponComponent from './Components/CouponComponent/ShowAllCouponComponent';
import ShowAllOrders from './Components/OrderComponent/ShowAllOrders';
function App() {

  return (
    <>
    <BrowserRouter>
                <div
                    style={{
                        display: "flex",
                        background: "black",
                        padding: "5px 0 5px 5px",
                        fontSize: "20px",
                    }}
                >
                    <div style={{ margin: "10px" }}>
                        <NavLink
                            to="/coupon"
                            style={({ isActive }) => ({
                                color: isActive
                                    ? "greenyellow"
                                    : "white",
                            })}
                        >
                            Coupon
                        </NavLink>
                    </div>
                    <div style={{ margin: "10px" }}>
                        <NavLink
                            to="/showAllCoupon"
                            style={({ isActive }) => ({
                                color: isActive
                                    ? "greenyellow"
                                    : "white",
                            })}
                        >
                            Show All Coupon
                        </NavLink>
                    </div>
                    <div style={{ margin: "10px" }}>
                        <NavLink
                            to="/order"
                            style={({ isActive }) => ({
                                color: isActive
                                    ? "greenyellow"
                                    : "white",
                            })}
                        >
                            Order
                        </NavLink>
                    </div>
                    <div style={{ margin: "10px" }}>
                        <NavLink
                            to="/ordercancel"
                            style={({ isActive }) => ({
                                color: isActive
                                    ? "greenyellow"
                                    : "white",
                            })}
                        >
                            ordercancel
                        </NavLink>
                    </div>
                    <div style={{ margin: "10px" }}>
                        <NavLink
                            to="/showAllOrder"
                            style={({ isActive }) => ({
                                color: isActive
                                    ? "greenyellow"
                                    : "white",
                            })}
                        >
                            Order Details
                        </NavLink>
                    </div>
                </div>
                <Routes>
                    <Route
                        exact
                        path="/coupon"
                        element={<CreateCouponComponent />}
                    />
                    <Route
                        exact
                        path="/showAllCoupon"
                        element={<ShowAllCouponComponent />}
                    />
                    <Route
                        exact
                        path="/order"
                        element={<Order />}
                    />
                    <Route
                        exact
                        path="/ordercancel"
                        element={<OrderCanceComponent />}
                    />
                    <Route
                        exact
                        path="/showAllOrder"
                        element={<ShowAllOrders />}
                    />
                </Routes>
            </BrowserRouter>
    </>
  );
}

export default App;
