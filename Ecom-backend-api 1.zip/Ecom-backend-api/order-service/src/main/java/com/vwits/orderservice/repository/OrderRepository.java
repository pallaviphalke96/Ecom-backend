package com.vwits.orderservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vwits.orderservice.Dto.OrderDto;
import com.vwits.orderservice.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{

	void save(OrderDto orderDto);

}
