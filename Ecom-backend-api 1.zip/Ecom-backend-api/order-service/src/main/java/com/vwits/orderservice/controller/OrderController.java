package com.vwits.orderservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vwits.orderservice.Dto.APIResponse;
import com.vwits.orderservice.Dto.OrderDto;
import com.vwits.orderservice.exception.InvalidCouponException;
import com.vwits.orderservice.exception.OrderNotFoundException;
import com.vwits.orderservice.service.OrderService;
import org.springframework.web.bind.annotation.RequestMethod;

@RestController
@RequestMapping("/api/order")

@CrossOrigin(origins = "http://localhost:3001",methods = {RequestMethod.POST,RequestMethod.GET,RequestMethod.PUT,RequestMethod.OPTIONS},allowedHeaders = "*")
public class OrderController {

	@Autowired
    private OrderService orderService;

    @GetMapping("/{id}")
    public ResponseEntity<APIResponse> getOrderById(@PathVariable int id) throws OrderNotFoundException {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }

    @PutMapping("/cancel/{id}")
    public ResponseEntity<String> cancelOrder(@PathVariable int id) throws OrderNotFoundException {
        orderService.cancelOrder(id);
        return ResponseEntity.ok("Booking cancelled successfuly");
    }
    
    @PostMapping
    public ResponseEntity<OrderDto> placeOrder(@RequestBody OrderDto orderDto) throws OrderNotFoundException, InvalidCouponException {
        return ResponseEntity.ok(orderService.placeOrder(orderDto));
    }
    
}
