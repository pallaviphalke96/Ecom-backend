package com.vwits.orderservice.service.impl;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vwits.orderservice.Dto.APIResponse;
import com.vwits.orderservice.Dto.CouponDto;
import com.vwits.orderservice.Dto.OrderDto;
import com.vwits.orderservice.entity.Order;
import com.vwits.orderservice.exception.OrderNotFoundException;
import com.vwits.orderservice.repository.OrderRepository;
import com.vwits.orderservice.service.CouponClient;
import com.vwits.orderservice.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	public OrderRepository orderRepository;
	
	@Autowired
	public ModelMapper modelMapper;
	
	@Autowired 
	private CouponClient couponClient;
	
	@Override
	public APIResponse getOrderById(int id) {
		Order order = orderRepository.findById(id).orElseThrow(() -> new OrderNotFoundException("Order Not Found With id :" +id));
		
		CouponDto couponDto = couponClient.getAllCoupon().get(id);
		 //couponDto.get(id);
		 OrderDto orderDto = modelMapper.map(order, OrderDto.class);
		 
		 APIResponse apiResponse = new APIResponse();
		 apiResponse.setOrder(orderDto);
		 apiResponse.setCoupon(couponDto);
		 return apiResponse;
		 
	}

	@Override
	public void cancelOrder(int id) {
		 Order order = orderRepository.findById(id).orElseThrow(() -> new OrderNotFoundException("Order Not Found With id: "+id));
	       order.setStatus("CANCELLED");
	       Order save = orderRepository.save(order);
		
	}


	public OrderDto placeOrder(OrderDto orderDto) {
		List <CouponDto> couponList=couponClient.getAllCoupon();//.getBody();
		@SuppressWarnings("unlikely-arg-type")
		int discount=couponList.stream().filter(i->i.getCouponId()==(orderDto.getCouponId())).map(i->i.getDiscount()).findFirst().orElse(0);
		orderDto.setPrice(orderDto.getPrice()-discount);
		Order order=modelMapper.map(orderDto,Order.class);
		orderRepository.save(order);
		return orderDto;
	}

}
