package com.vwits.orderservice.Dto;

import java.util.List;

import com.vwits.orderservice.Dto.CouponDto;
import com.vwits.orderservice.Dto.OrderDto;

public class APIResponse {
	
	private OrderDto order;
	
	//private List<CouponDto> coupon;
	
	private CouponDto coupon;
	
	public APIResponse() {
		super();
	}

	public OrderDto getOrder() {
		return order;
	}

	public void setOrder(OrderDto order) {
		this.order = order;
	}

	public CouponDto getCoupon() {
		return coupon;
	}

	public void setCoupon(CouponDto coupon) {
		this.coupon = coupon;
	}





//	public List<CouponDto> getCoupon() {
//		return coupon;
//	}
//
//
//
//	public void setCoupon(List<CouponDto> coupon) {
//		this.coupon = coupon;
//	}
//	
	
	
	

}
