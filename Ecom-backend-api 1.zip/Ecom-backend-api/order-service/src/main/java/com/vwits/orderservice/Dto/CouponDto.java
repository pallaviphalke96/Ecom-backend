package com.vwits.orderservice.Dto;


public class CouponDto {

	 private int couponId;
		
	 private String couponCode;
	 
	 private int discount;
	 
	public int getCouponId() {
		return couponId;
	}
	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}
	
	public CouponDto() {
		super();
	}
	public CouponDto(int couponId, String couponCode, int discount) {
		super();
		this.couponId = couponId;
		this.couponCode = couponCode;
		this.discount = discount;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	 
	 
	 
 
}



