package com.vwits.orderservice.Dto;

public class OrderDto {

	private int id;
    private String item;
    private int price;
    private String status;
    private int couponId;
    
    
	public int getCouponId() {
		return couponId;
	}
	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}
	
	public OrderDto() {
		super();
	}
	public OrderDto(int id, String item, int price, String status) {
		super();
		this.id = id;
		this.item = item;
		this.price = price;
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
    
}
