package com.vwits.orderservice.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.vwits.orderservice.Dto.CouponDto;

@FeignClient(url="http://localhost:8888", value="coupon-service")
public interface CouponClient {
	
	@GetMapping("/api/coupon")
	public List<CouponDto> getAllCoupon();

}
