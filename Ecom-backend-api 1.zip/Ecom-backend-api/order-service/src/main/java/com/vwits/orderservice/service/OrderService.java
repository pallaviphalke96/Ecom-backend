package com.vwits.orderservice.service;

import com.vwits.orderservice.Dto.APIResponse;
import com.vwits.orderservice.Dto.OrderDto;

public interface OrderService {

	APIResponse getOrderById(int id);

    void cancelOrder(int id); //throws OrderNotFoundException;

    //Order placeOrder(Order order);// throws OrderNotFoundException, InvalidCouponException;

    OrderDto placeOrder(OrderDto orderDto);
}
