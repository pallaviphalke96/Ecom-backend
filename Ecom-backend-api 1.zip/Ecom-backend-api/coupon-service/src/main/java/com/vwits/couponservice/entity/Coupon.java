package com.vwits.couponservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_coupon")
public class Coupon {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int couponId;
	
	 @Column(unique = true)
	 private String couponCode;
	 
	 private int discount;
	 
	public int getCouponId() {
		return couponId;
	}
	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public Coupon() {
		super();
	}
	public Coupon(int couponId, String couponCode, int discount) {
		super();
		this.couponId = couponId;
		this.couponCode = couponCode;
		this.discount = discount;
	}
	
	
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	 
	 
	 
 
}


