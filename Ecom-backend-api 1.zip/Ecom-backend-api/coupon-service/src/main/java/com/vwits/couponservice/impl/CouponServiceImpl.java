package com.vwits.couponservice.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vwits.couponservice.Dto.CouponDto;
import com.vwits.couponservice.entity.Coupon;
import com.vwits.couponservice.repository.CouponRepository;
import com.vwits.couponservice.service.CouponService;

@Service
public class CouponServiceImpl implements CouponService{
 
	@Autowired
	private CouponRepository couponRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public CouponDto createCoupon(CouponDto couponDto) {
		Coupon coupon = modelMapper.map(couponDto, Coupon.class);
		Coupon save = couponRepository.save(coupon);
		return modelMapper.map(save, CouponDto.class);
	}

	@Override
	public List<CouponDto> getAllCoupons() {
		List<Coupon> Coupons = couponRepository.findAll();
		return Coupons.stream().map(coupon->modelMapper.map(coupon, CouponDto.class)).toList();
	}

}
