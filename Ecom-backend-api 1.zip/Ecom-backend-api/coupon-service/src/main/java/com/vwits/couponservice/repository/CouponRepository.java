package com.vwits.couponservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vwits.couponservice.entity.Coupon;

public interface CouponRepository extends JpaRepository<Coupon, Integer>{

}
