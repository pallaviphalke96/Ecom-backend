package com.vwits.couponservice.service;

import java.util.List;

import com.vwits.couponservice.Dto.CouponDto;

public interface CouponService {
	
	CouponDto createCoupon(CouponDto couponDto);

    List<CouponDto> getAllCoupons();

}
